package aula_oo;

public class Pessoa {
    public int id;
    public String nome;
    public String telefone;
    public Cidade cidade;

    // Constructors
    // Vazio
    public Pessoa() {
    }
    // Gera id e pede preenchimento dos outros valores
    public Pessoa(String nome, String telefone, Cidade cidade) {
        this.nome = nome;
        this.telefone = telefone;
        // Força resultado do double para int
        int id = (int) (Math.random() * 100);
        this.id = id;
        this.cidade = cidade;
    }
    // Complete Constructor
    public Pessoa(int id, String nome, String telefone, Cidade cidade) {
        this.id = id;
        this.nome = nome;
        this.telefone = telefone;
        this.cidade = cidade;
    }


    public void imprimir() {
        System.out.println("ID: " + this.id);
        System.out.println("Nome: " + this.nome);
        System.out.println("Telefone: " + this.telefone);
        System.out.println("Cidade: " + this.cidade.nome);
    }
}