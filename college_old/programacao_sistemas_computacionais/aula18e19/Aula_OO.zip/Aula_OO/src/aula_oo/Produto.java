package aula_oo;

public class Produto {
    public int id;
    public String nome;
    public double preco;
    public double quantidade;
    public Categoria categoria;

    public Produto() {
    }
    public Produto(int id, String nome, double preco, double quantidade, Categoria categoria) {
        this.id = id;
        this.nome = nome;
        this.preco = preco;
        this.quantidade = quantidade;
        this.categoria = categoria;
    }
    
    public void imprimir() {
        System.out.println("Código: " + this.id);
        System.out.println("Nome: " + this.nome);
        System.out.println("Preço: " + this.preco);
        System.out.println("Quantidade: " + this.quantidade);
        System.out.println("Categoria: " + this.categoria);
    }
}