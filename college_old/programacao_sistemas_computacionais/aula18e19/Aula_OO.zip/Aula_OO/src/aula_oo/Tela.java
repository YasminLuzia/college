package aula_oo;

public class Tela {
    public static void main(String[] args) {

        /*
         * int idade = 20;
         * double y = 1.5;
         * String nome = "Yasmin";
         * boolean temFilhos = false;
         * String texto = nome + " - " + idade;
         * System.out.println(texto);
         */

        Cidade c1 = new Cidade();
        c1.id = 1;
        c1.nome = "Porto Alegre";
        c1.imprimir();

        Cidade c2 = new Cidade(2, "Capão da Canoa");

        System.out.println("-----------------------");

        Pessoa p1 = new Pessoa();
        p1.id = 1;
        p1.nome = "Yasmin da Silva";
        p1.telefone = "(51) 99955-5566";
        p1.cidade = c1;
        p1.imprimir();

        System.out.println("-----------------------");

        Pessoa p2 = new Pessoa("Beltrano da Silva", "(51) 99885-5522", c2);
        p2.imprimir();

        System.out.println("-----------------------");

        Pessoa p3 = new Pessoa(3, "Ciclano da Silva", "(51) 99335-8989", c1);
        p3.imprimir();
    }
}
