package aula_oo;

public class Cidade {
    public int id;
    public String nome;

    // Constructors
    public Cidade() {
    }
    public Cidade(int id, String nome) {
        this.id = id;
        this.nome = nome;
    }

    public void imprimir() {
        System.out.println("Código: " + this.id);
        System.out.println("Nome: " + this.nome);
    }
}